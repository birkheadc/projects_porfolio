export type BulletPoint = {
  language: string,
  content: string[]
}