export type ProjectDescription = {
  language: string,
  content: string
}